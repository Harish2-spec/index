// S. Harish portfolio interactions
const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
const navItems = document.querySelectorAll(".nav-links a");

if (menuButton && navLinks) {
  menuButton.addEventListener("click", () => {
    const isOpen = menuButton.getAttribute("aria-expanded") === "true";
    menuButton.setAttribute("aria-expanded", String(!isOpen));
    menuButton.setAttribute("aria-label", isOpen ? "Open navigation menu" : "Close navigation menu");
    navLinks.classList.toggle("open", !isOpen);
  });

  navItems.forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");
      menuButton.setAttribute("aria-label", "Open navigation menu");
    });
  });
}

// Typing animation in the hero heading
const typedText = document.querySelector(".typed-text");
const phrases = ["software development", "web development", "cloud computing", "problem-solving"];
let phraseIndex = 0;
let characterIndex = 0;
let deleting = false;

function typePhrase() {
  if (!typedText || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    if (typedText) typedText.textContent = phrases[0];
    return;
  }

  const currentPhrase = phrases[phraseIndex];
  typedText.textContent = currentPhrase.slice(0, characterIndex);

  if (!deleting && characterIndex < currentPhrase.length) {
    characterIndex++;
    setTimeout(typePhrase, 75);
  } else if (deleting && characterIndex > 0) {
    characterIndex--;
    setTimeout(typePhrase, 35);
  } else {
    deleting = !deleting;
    if (!deleting) phraseIndex = (phraseIndex + 1) % phrases.length;
    setTimeout(typePhrase, deleting ? 1300 : 300);
  }
}
typePhrase();

// Reveal sections as they enter the viewport
const revealElements = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window) {
  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealElements.forEach((element) => revealObserver.observe(element));
} else {
  revealElements.forEach((element) => element.classList.add("visible"));
}

// Scroll progress indicator
const progressBar = document.querySelector(".scroll-progress");
function updateScrollProgress() {
  if (!progressBar) return;
  const scrollableHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = scrollableHeight > 0 ? (window.scrollY / scrollableHeight) * 100 : 0;
  progressBar.style.width = `${progress}%`;
}
window.addEventListener("scroll", updateScrollProgress, { passive: true });
updateScrollProgress();

// Highlight the current navigation section
const sections = document.querySelectorAll("main section[id]");
if ("IntersectionObserver" in window) {
  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        navItems.forEach((link) => {
          link.classList.toggle("active", link.getAttribute("href") === `#${entry.target.id}`);
        });
      }
    });
  }, { rootMargin: "-35% 0px -55% 0px" });
  sections.forEach((section) => sectionObserver.observe(section));
}
